//package pl.zajavka.domain;
//
//import lombok.*;
//
//@NoArgsConstructor
//@AllArgsConstructor
//@Data
//@With
//@Builder
//@EqualsAndHashCode(of = "id")
//public class Role {
//    Integer id;
//    String role;
//}
