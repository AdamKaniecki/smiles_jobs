//package pl.zajavka.infrastructure.security;
////
//import jakarta.servlet.ServletException;
//import jakarta.servlet.http.HttpServletRequest;
//import jakarta.servlet.http.HttpServletResponse;
//import org.springframework.security.core.Authentication;
//import org.springframework.security.core.GrantedAuthority;
//import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
//import org.springframework.security.web.authentication.SimpleUrlAuthenticationSuccessHandler;
//
//import java.io.IOException;
//import java.util.Collection;
//
//public class CustomAuthenticationSuccessHandler extends SimpleUrlAuthenticationSuccessHandler {
//
//    @Override
//    protected void handle(HttpServletRequest request, HttpServletResponse response, Authentication authentication)
//            throws IOException, ServletException {
//        String targetUrl = determineTargetUrl(authentication);
//        if (response.isCommitted()) {
//            return;
//        }
//        clearAuthenticationAttributes(request);
//        getRedirectStrategy().sendRedirect(request, response, targetUrl);
//    }
//
//    protected String determineTargetUrl(Authentication authentication) {
//        Collection<? extends GrantedAuthority> authorities = authentication.getAuthorities();
//        for (GrantedAuthority authority : authorities) {
//            if (authority.getAuthority().equals("ROLE_CANDIDATE")) {
//                return "/candidate_portal";
//            } else if (authority.getAuthority().equals("ROLE_COMPANY")) {
//                return "/company_portal";
//            }
//        }
//        // Domyślny URL, jeśli rola nie jest ani "ROLE_CANDIDATE" ani "ROLE_COMPANY"
//        return "/";
//    }
//}
