//package pl.zajavka.infrastructure.security.mapper;
//
//import org.mapstruct.Mapper;
//import org.mapstruct.ReportingPolicy;
//import pl.zajavka.domain.Role;
//import pl.zajavka.infrastructure.security.RoleEntity;
//
//@Mapper(componentModel = "spring",unmappedTargetPolicy = ReportingPolicy.IGNORE)
//public interface RoleMapper {
//    Role map(RoleEntity roleEntity);
//    RoleEntity map(Role role);
//}
