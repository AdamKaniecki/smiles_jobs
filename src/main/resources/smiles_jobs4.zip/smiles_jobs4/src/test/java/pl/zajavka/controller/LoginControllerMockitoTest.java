package pl.zajavka.controller;

//
//@WebMvcTest(controllers = LoginController.class)
//@AutoConfigureMockMvc(addFilters = false)
//@AllArgsConstructor(onConstructor = @__(@Autowired))
//class LoginControllerMockitoTest {
//
//
//
//}